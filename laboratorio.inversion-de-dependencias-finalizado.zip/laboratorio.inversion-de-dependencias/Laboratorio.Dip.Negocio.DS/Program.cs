﻿using Laboratorio.Dip.Negocio.DS.ValoracionesEnColones.Parametros;
using Laboratorio.Dip.Negocio.ValoracionesEnColones;
using System;

namespace Laboratorio.Dip.Negocio.DS
{
    class Program
    {
        static void Main(string[] args)
        {
            // Esos son los mismos datos usados en las pruebas unitarias
            DatosDelISINEnColonesConDependencias losDatos = new DatosDelISINEnColonesConDependencias();
            losDatos.ISIN = "HDA000000000001";
            losDatos.FechaDeVencimientoDelValorOficial = new DateTime(2016, 6, 6); ;
            losDatos.DiasMinimosAlVencimientoDelEmisor = 7;
            losDatos.PorcentajeCobertura = 0.8M;
            losDatos.PrecioLimpioDelVectorDePrecios = 80;
            losDatos.MontoNominalDelSaldo = 3578000;

            // pero la ejecucion sera diferente cada dia pues depende de la fecha actual
            ValoracionPorISIN laValoracion = new ValoracionPorISIN(losDatos);

            Console.WriteLine("Resultado de la Valoracion:");
            Console.WriteLine($" ISIN {laValoracion.ISIN}");
            Console.WriteLine($" PorcentajeCobertura {laValoracion.PorcentajeCobertura}");
            Console.WriteLine($" ValorDeMercado {laValoracion.ValorDeMercado}");
            Console.WriteLine($" AporteDeGarantia {laValoracion.AporteDeGarantia}");
            Console.ReadLine();
        }
    }
}