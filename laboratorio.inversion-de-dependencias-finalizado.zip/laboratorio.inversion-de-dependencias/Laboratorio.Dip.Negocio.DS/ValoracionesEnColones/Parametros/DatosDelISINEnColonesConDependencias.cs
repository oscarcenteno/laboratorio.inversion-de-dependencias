﻿using Laboratorio.Dip.Negocio.ValoracionesEnColones;
using System;

namespace Laboratorio.Dip.Negocio.DS.ValoracionesEnColones.Parametros
{
    class DatosDelISINEnColonesConDependencias : DatosDelISINEnColones
    {
        public override DateTime FechaActual
        {
            get
            {
                return DateTime.Now;
            }
        }
    }
}
